const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')

const app = express()
app.use(bodyParser.json())

mongoose.connect('mongodb+srv://user1:passwordforuser1@cluster0.ythtdnc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0').then(() => {
	console.log('MongoDB connected!')
}).catch((err) => {
	console.error('Connection error:', err)
})

const userRoutes = require('./routes/userRoutes')
app.use('/', userRoutes)

app.listen(3000, () => {
	console.log('Server running on port 3000')
})