const express = require('express')
const router = express.Router()
const User = require('../models/User')

router.post('/addUser', (req, res) => {
	const newUser = new User({
		firstname: req.body.firstname,
		lastname: req.body.lastname,
		email: req.body.email,
		phone: req.body.phone,
		password: req.body.password
	})

	newUser.save()
		.then(user => res.json(user))
		.catch(err => res.status(400).json('Error: ' + err))
})

module.exports = router